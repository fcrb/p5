function setup() {
  createCanvas(600,400);
  background(50,75,100);
  line(0,0,600,400);
  line(0,0,400,600);
  line(0,0,1200,400);
  line(0,0,200,1000);
  line(0,0,1700,200);
}

function draw() {
  fill(204,204,255);
  
  
}