function setup (){
  createCanvas(1000,1000);
  background(0,200,255);
}

function draw (){
  
}